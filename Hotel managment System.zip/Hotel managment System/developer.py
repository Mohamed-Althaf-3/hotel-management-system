from tkinter import*
from PIL import Image,ImageTk
from tkinter import ttk
import tkinter as tk
import mysql.connector
import random
from tkinter import messagebox

class developer1:
	
	def __init__(self,root):
		self.root=root
		self.root.title("Hotel Managment System")
		self.root.geometry("1295x550+230+220")

		img1 = Image.open(r"C:\Users\HP\Desktop\note\DDD\DB.png")
		img1 = img1.resize((1310,590),Image.ANTIALIAS)
		self.photoimg1 = ImageTk.PhotoImage(img1)

		lb1img = Label(self.root,image=self.photoimg1,bd=4,relief=RIDGE)
		lb1img.place(x=0,y=-30,width=1310, height=590)
	

if __name__ == "__main__":
		root=Tk()
		obj= developer1(root) 
		root.mainloop()